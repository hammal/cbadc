"""
Down Sampling
=====================

In this tutorial we demonstrate how to configure the digital estimator
for down sampling.
"""